#!/bin/bash
#19/12/2019
clear
msg -bar

BadVPN () {
if [[ -z $(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND"|grep "badvpn-ud"|awk '{print $1}') ]]; then
    msg -ama "                  INICIADO BADVPN"
    msg -bar

echo -e "[Unit]
Description=BadVPN UDPGW Service
After=network.target\n
[Service]
Type=simple
User=root
WorkingDirectory=/root
ExecStart=/usr/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10
Restart=always
RestartSec=3s\n
[Install]
WantedBy=multi-user.target" > /etc/systemd/system/badvpn.service

    systemctl enable badvpn &>/dev/null
    systemctl start badvpn &>/dev/null
    sleep 2
    [[ -z $(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND"|grep "badvpn-ud"|awk '{print $1}') ]] && msg -verm2 "                  FALLA AL INICIAR" || msg -verd "                  BADVPN INICIADO" 
    msg -bar
    sleep 1
else
    msg -ama "                DETENIENDO BADVPN"
    msg -bar
    systemctl stop badvpn &>/dev/null
    systemctl disable badvpn &>/dev/null
    rm /etc/systemd/system/badvpn.service
    sleep 2
    [[ -z $(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND"|grep "badvpn-ud"|awk '{print $1}') ]] && msg -ama "                 BADVPN DETENIDO" || msg -verm2 "                FALLA AL DETENER"
    msg -bar
    sleep 1  
fi
unset st_badvpn
return 1
}
        if [[ ! -e /usr/bin/badvpn-udpgw ]]; then
            echo -ne "$(msg -azu " INSTALADO DEPENDECIAS...") "

            if apt install cmake -y &>/dev/null; then
                msg -verd "[OK]"
            else
                msg -verm2 "[fail]"
                slee 3
                return
            fi
            cd ${ADM_src}
            echo -ne "$(msg -azu " DESCARGANDO BADVPN......") "
            if wget https://github.com/rudi9999/ADMRufu/raw/main/Utils/badvpn/badvpn-master.zip &>/dev/null; then
                msg -verd "[OK]"
            else
                msg -verm2 "[fail]"
                slee 3
                return
            fi

            echo -ne "$(msg -azu " DESCOMPRIMIENDO.........") "
            if unzip badvpn-master.zip &>/dev/null; then
                msg -verd "[OK]"
            else
                msg -verm2 "[fail]"
                slee 3
                return
            fi
            cd badvpn-master
            mkdir build
            cd build

            echo -ne "$(msg -azu " COMPILANDO BADVPN.......") "
            if cmake .. -DCMAKE_INSTALL_PREFIX="/" -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 &>/dev/null && make install &>/dev/null; then
                msg -verd "[OK]"
            else
                msg -verm2 "[fail]"
                slee 3
                return
            fi
            cd $HOME
            rm ${ADM_src}/badvpn-master.zip &>/dev/null
        fi
BadVPN
