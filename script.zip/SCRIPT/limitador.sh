#!/bin/bash
droppids(){
  port_dropbear=`ps aux|grep 'dropbear'|awk NR==1|awk '{print $17;}'`

  log=/var/log/auth.log
  loginsukses='Password auth succeeded'

  pids=`ps ax|grep 'dropbear'|grep " $port_dropbear"|awk -F " " '{print $1}'`

  for pid in $pids; do
    pidlogs=`grep $pid $log |grep "$loginsukses" |awk -F" " '{print $3}'`

    i=0
    for pidend in $pidlogs; do
      let i=i+1
    done

    if [ $pidend ];then
       login=`grep $pid $log |grep "$pidend" |grep "$loginsukses"`
       PID=$pid
       user=`echo $login |awk -F" " '{print $10}' | sed -r "s/'/ /g"`
       waktu=`echo $login |awk -F" " '{print $2"-"$1,$3}'`
       while [ ${#waktu} -lt 13 ]; do
           waktu=$waktu" "
       done
       while [ ${#user} -lt 16 ]; do
           user=$user" "
       done
       while [ ${#PID} -lt 8 ]; do
           PID=$PID" "
       done
       echo "$user $PID $waktu"
    fi
done
}

sshmonitor(){
    for i in `cat /etc/passwd|grep 'home'|grep 'false'|awk -F ':' '{print $1}'`; do
        user="$i"
        s2ssh="$(cat /etc/passwd|grep "$i"|cut -d ':' -f5)"

        if [[ "$(cat /etc/passwd| grep -w $user| wc -l)" = "1" ]]; then
          sqd="$(ps -u $user | grep sshd | wc -l)"
        else
          sqd=00
        fi
        [[ "$sqd" = "" ]] && sqd=0

        if [[ -e /etc/openvpn/openvpn-status.log ]]; then
          ovp="$(cat /etc/openvpn/openvpn-status.log | grep -E ,"$user", | wc -l)"
        else
          ovp=0
        fi

        if netstat -nltp|grep 'dropbear'> /dev/null;then
          drop="$(droppids | grep "$user" | wc -l)"
        else
          drop=0
        fi

        cnx=$(($sqd + $drop))
        conex=$(($cnx + $ovp))

        if [[ "$conex" -gt "$s2ssh" ]]; then
        	pkill -u $user
        	droplim=`droppids|grep -w "$user"|awk '{print $2}'` 
        	kill -9 $droplim &>/dev/null
        	usermod -L $user
        	echo "$user $(printf '%(%H:%M:%S)T') $conex/$s2ssh" >> /etc/ADMRufu/user/limit.log
        	at now +1 minutes <<< "usermod -U $user" &>/dev/null
        fi
      done
}
sshmonitor
touch /etc/ADMRufu/user/limit
timer=$(cat /etc/ADMRufu/user/limit)
[[ -z ${timer} ]] && timer="3"
at now +${timer} minutes <<< "/etc/ADMRufu/install/limitador.sh" &>/dev/null
[[ -z $(cat "/var/spool/cron/crontabs/root"|grep "limitador.sh") ]] && echo "@reboot /etc/ADMRufu/install/limitador.sh" >> /var/spool/cron/crontabs/root
